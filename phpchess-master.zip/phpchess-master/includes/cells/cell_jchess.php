<br>
<center>
<applet 
    code="jchess.class" 
    archive="jchess.zip" 
    name="jchess" 
    width="400" 
    height="400"
    <PARAM NAME="color" VALUE="#5aa6b5">
    <PARAM NAME="whtfld" VALUE="#FFFFFF">
    <PARAM NAME="blkfld" VALUE="#5aa6b5">
</applet>
</center>